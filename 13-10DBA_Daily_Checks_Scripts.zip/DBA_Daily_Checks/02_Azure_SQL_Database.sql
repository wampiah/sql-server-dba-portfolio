/* Run in EACH Azure SQL user database, not logical master.
   Read-only, apart from session temp tables. Uses UTC throughout.
   Recent resource DMV has approximately ONE HOUR, not 24 hours.
   Use 03_Azure_Platform.ps1/Azure Monitor for the longer window.
*/
SET NOCOUNT ON;
DECLARE @OldLockTimeout int=@@LOCK_TIMEOUT;
DECLARE @Utc datetime2=SYSUTCDATETIME(), @CpuWarn int=80, @IOWarn int=80,
 @WorkerWarn int=80, @GeoLagWarnSeconds int=60; -- sample thresholds; tune locally
IF CONVERT(int,SERVERPROPERTY('EngineEdition'))<>5
 THROW 50000,'This script is for Azure SQL Database only.',1;
IF DB_NAME()='master' THROW 50000,'Connect directly to the target user database.',1;
SET LOCK_TIMEOUT 3000;
IF OBJECT_ID('tempdb..#AzureDaily') IS NOT NULL DROP TABLE #AzureDaily;
CREATE TABLE #AzureDaily(CheckTimeUtc datetime2,Resource nvarchar(512),CheckName nvarchar(100),
 Status varchar(20),Finding nvarchar(max),Evidence nvarchar(max));
INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Connectivity','PASS',
 'This database connection succeeded. Test application-path connectivity separately.',
 CONCAT('Server=',SERVERPROPERTY('ServerName')));
BEGIN TRY
 EXEC sp_executesql N'
 INSERT #AzureDaily SELECT @u,DB_NAME(),''Service objective'',''INFO'',
 CONCAT(''Edition='',edition,''; objective='',service_objective,''; pool='',elastic_pool_name),
 ''sys.database_service_objectives'' FROM sys.database_service_objectives WHERE database_id=DB_ID();',N'@u datetime2',@Utc;
END TRY BEGIN CATCH
 INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Service objective','NOT CHECKED',ERROR_MESSAGE(),NULL);
END CATCH;
BEGIN TRY
 EXEC sp_executesql N'
 IF NOT EXISTS(SELECT 1 FROM sys.dm_db_resource_stats) RAISERROR(''No resource samples available.'',16,1);
 INSERT #AzureDaily SELECT @u,DB_NAME(),''Recent resource utilisation'',
 CASE WHEN MAX(avg_cpu_percent)>=@c OR MAX(avg_data_io_percent)>=@i
 OR MAX(avg_log_write_percent)>=@i OR MAX(max_worker_percent)>=@w THEN ''REVIEW'' ELSE ''INFO'' END,
 CONCAT(''Samples='',COUNT(*),''; earliest UTC='',CONVERT(varchar(30),MIN(end_time),126),
 ''; latest UTC='',CONVERT(varchar(30),MAX(end_time),126),
 ''; peak CPU='',MAX(avg_cpu_percent),''; peak data IO='',MAX(avg_data_io_percent),
 ''; peak log IO='',MAX(avg_log_write_percent),''; peak workers='',MAX(max_worker_percent),
 ''; peak sessions='',MAX(max_session_percent)),
 ''Approximately 1-hour retention; peaks alone do not prove sustained saturation''
 FROM sys.dm_db_resource_stats;',N'@u datetime2,@c int,@i int,@w int',@Utc,@CpuWarn,@IOWarn,@WorkerWarn;
END TRY BEGIN CATCH
 INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Recent resource utilisation','NOT CHECKED',ERROR_MESSAGE(),NULL);
END CATCH;
BEGIN TRY
 EXEC sp_executesql N'
 INSERT #AzureDaily SELECT @u,DB_NAME()+''/''+name,''Data file usage'',''INFO'',
 CONCAT(''Allocated MB='',CAST(size/128.0 AS decimal(18,2)),
 ''; used MB='',CAST(FILEPROPERTY(name,''SpaceUsed'')/128.0 AS decimal(18,2)),
 ''; database max bytes='',DATABASEPROPERTYEX(DB_NAME(),''MaxSizeInBytes'')),
 ''Data-file usage; verify service-tier storage metrics including pool/Hyperscale limits separately''
 FROM sys.database_files WHERE type=0;
 INSERT #AzureDaily SELECT @u,DB_NAME(),''Log usage'',''INFO'',
 CONCAT(''Allocated MB='',CAST(total_log_size_in_bytes/1048576.0 AS decimal(18,2)),
 ''; used percent='',CAST(used_log_space_in_percent AS decimal(8,2))),
 ''sys.dm_db_log_space_usage; current snapshot'' FROM sys.dm_db_log_space_usage;',N'@u datetime2',@Utc;
END TRY BEGIN CATCH
 INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Database space','NOT CHECKED',ERROR_MESSAGE(),NULL);
END CATCH;
BEGIN TRY
 IF ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW DATABASE STATE'),0)<>1
 AND ISNULL(HAS_PERMS_BY_NAME(DB_NAME(),'DATABASE','VIEW DATABASE PERFORMANCE STATE'),0)<>1
 RAISERROR('Database-wide monitoring permission missing; requests may be hidden.',16,1);
 EXEC sp_executesql N'
 INSERT #AzureDaily SELECT @u,DB_NAME(),''Current blocked request'',''REVIEW'',
 CONCAT(''Session='',session_id,''; blocker='',blocking_session_id,''; wait='',wait_type,
 ''; wait ms='',wait_time,''; elapsed ms='',total_elapsed_time),
 ''Current requests only; no application SQL text collected''
 FROM sys.dm_exec_requests WHERE database_id=DB_ID() AND session_id<>@@SPID AND blocking_session_id<>0;
 IF @@ROWCOUNT=0 INSERT #AzureDaily VALUES(@u,DB_NAME(),''Current blocking'',''PASS'',
 ''No blocked requests visible now; no claim about overnight blocking.'',NULL);',N'@u datetime2',@Utc;
END TRY BEGIN CATCH
 INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Current blocking','NOT CHECKED',ERROR_MESSAGE(),NULL);
END CATCH;
BEGIN TRY
 EXEC sp_executesql N'
 INSERT #AzureDaily SELECT @u,DB_NAME(),''Geo replication'',
 CASE WHEN replication_state_desc NOT IN(''CATCH_UP'') THEN ''REVIEW''
 WHEN replication_lag_sec>@lag THEN ''ATTENTION''
 WHEN replication_lag_sec IS NULL THEN ''REVIEW'' ELSE ''INFO'' END,
 CONCAT(''Partner='',partner_server,''/'',partner_database,''; state='',replication_state_desc,
 ''; lag seconds='',replication_lag_sec,''; last replication='',CONVERT(varchar(30),last_replication,126)),
 ''sys.dm_geo_replication_link_status; lag may be NULL on secondary; validate configured topology''
 FROM sys.dm_geo_replication_link_status;
 IF @@ROWCOUNT=0 INSERT #AzureDaily VALUES(@u,DB_NAME(),''Geo replication'',''REVIEW'',
 ''No visible geo link; confirm whether configured/required.'',NULL);',N'@u datetime2,@lag int',@Utc,@GeoLagWarnSeconds;
END TRY BEGIN CATCH
 INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Geo replication','NOT CHECKED',ERROR_MESSAGE(),NULL);
END CATCH;
INSERT #AzureDaily VALUES(@Utc,DB_NAME(),'Platform and retained history','NOT CHECKED',
 'Review Azure alerts, 24-hour metrics, restore coverage, automation outcomes, historical deadlocks, Query Store regressions and security alerts separately.',
 'SQL Database has no local SQL Agent/msdb backup history');
SET LOCK_TIMEOUT @OldLockTimeout;
SELECT *,CAST(NULL AS nvarchar(100)) Ticket,CAST(NULL AS nvarchar(100)) Owner,
 CAST(NULL AS nvarchar(100)) NextUpdate FROM #AzureDaily
ORDER BY CASE Status WHEN 'ATTENTION' THEN 1 WHEN 'NOT CHECKED' THEN 2 WHEN 'REVIEW' THEN 3 ELSE 4 END,CheckName;
