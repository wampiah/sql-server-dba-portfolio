<# Read-only Azure control-plane checks. No SQL connections or remediation.
   Requires an existing authenticated Az session and appropriate read permissions.
   Writes local CSV/JSON evidence only. Never sends email.
   Each resource ID must be in the subscription selected in the current context.
#>
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][string]$ConfigPath,
 [string]$OutputDirectory = '.\AzureDailyOutput',
 [ValidateRange(1,168)][int]$Hours = 24
)
$ErrorActionPreference = 'Stop'
foreach ($command in @('Get-AzContext','Get-AzResource','Invoke-AzRestMethod',
 'Get-AzMetric','Get-AzMetricDefinition','Get-AzActivityLog')) {
 if (-not (Get-Command $command -ErrorAction SilentlyContinue)) {
  throw "Missing command $command. Install the required Az modules separately; see README."
 }
}
$context = Get-AzContext
if (-not $context -or -not $context.Subscription.Id) { throw 'Authenticate and select the intended subscription first.' }
$config = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
if (-not $config.Resources -or @($config.Resources).Count -eq 0) { throw 'Supply at least one resource in the configuration.' }
foreach ($item in $config.Resources) {
 if ($item.ResourceId -notmatch '^/subscriptions/([^/]+)/resourceGroups/[^/]+/providers/[^/]+/.+') {
  throw "Invalid resource ID: $($item.ResourceId)"
 }
 if ($Matches[1] -ne $context.Subscription.Id) { throw 'Resource subscription differs from current context. Run once per subscription.' }
 foreach ($metric in @($item.Metrics)) {
  if ($null -eq $metric) { continue }
  if (-not $metric.Name -or $null -eq $metric.WarningValue -or [double]$metric.WarningValue -lt 0) {
   throw 'Each metric needs a name and a non-negative WarningValue.'
  }
 }
}
$endUtc = [DateTime]::UtcNow
$startUtc = $endUtc.AddHours(-$Hours)
$rows = [System.Collections.Generic.List[object]]::new()
$details = [System.Collections.Generic.List[object]]::new()
function Add-Outcome([string]$id,[string]$check,[string]$status,[string]$finding,[string]$evidence) {
 $rows.Add([pscustomobject]@{CheckTimeUtc=$endUtc.ToString('o');Resource=$id;CheckName=$check;
  Status=$status;Finding=$finding;Evidence=$evidence;Ticket='';Owner='';NextUpdate=''})
}
foreach ($item in $config.Resources) {
 $id = [string]$item.ResourceId
 try {
  $resource = Get-AzResource -ResourceId $id -ExpandProperties
  $details.Add([pscustomobject]@{Resource=$id;Check='Resource';Data=$resource})
  Add-Outcome $id 'Resource inventory' 'INFO' "Type=$($resource.ResourceType); location=$($resource.Location)" 'ARM resource read succeeded; not a database connectivity test'
 } catch { Add-Outcome $id 'Resource inventory' 'NOT CHECKED' $_.Exception.Message 'ARM resource read' }
 try {
  $response=Invoke-AzRestMethod -Method GET -Path ($id+'/providers/Microsoft.ResourceHealth/availabilityStatuses/current?api-version=2025-05-01')
  if ([int]$response.StatusCode -ne 200) { throw "Resource Health HTTP status $($response.StatusCode)" }
  $health=$response.Content | ConvertFrom-Json
  $state=[string]$health.properties.availabilityState
  $status=if($state -eq 'Available'){'PASS'}elseif($state -in @('Unavailable','Degraded')){'ATTENTION'}else{'NOT CHECKED'}
  Add-Outcome $id 'Resource Health' $status "State=$state; $($health.properties.summary)" "Current platform health only; reported=$($health.properties.reportedTime)"
  $details.Add([pscustomobject]@{Resource=$id;Check='ResourceHealth';Data=$health})
 } catch { Add-Outcome $id 'Resource Health' 'NOT CHECKED' $_.Exception.Message 'May be unsupported for this resource or inaccessible' }
 try {
  # 30 days is the API's longest exposed TimeRange; old still-fired alerts may be absent.
  $alerts=[System.Collections.Generic.List[object]]::new()
  $next='/subscriptions/'+$context.Subscription.Id+'/providers/Microsoft.AlertsManagement/alerts?api-version=2019-03-01&timeRange=30d&targetResource='+[Uri]::EscapeDataString($id)
  $pages=0
  while($next){
   $pages++
   if($pages -gt 100){throw 'Alert pagination exceeded 100 pages; narrow the scope.'}
   $alertResponse=Invoke-AzRestMethod -Method GET -Path $next
   if([int]$alertResponse.StatusCode -ne 200){throw "Alerts HTTP status $($alertResponse.StatusCode)"}
   $page=$alertResponse.Content | ConvertFrom-Json
   foreach($alert in @($page.value)){if($null -ne $alert){$alerts.Add($alert)}}
   $next=$null
   if($page.nextLink){$next=([Uri]$page.nextLink).PathAndQuery}
  }
  $details.Add([pscustomobject]@{Resource=$id;Check='Alerts30Days';Data=$alerts.ToArray()})
  $active=@($alerts | Where-Object { $_.properties.essentials.monitorCondition -eq 'Fired' })
  $status=if($active.Count -gt 0){'ATTENTION'}else{'REVIEW'}
  Add-Outcome $id 'Azure alerts' $status "Still-fired alerts visible in 30-day query=$($active.Count); returned alerts=$($alerts.Count)" 'Review evidence JSON; paginated REST collection; confirm old alerts and rule coverage in Azure Monitor/Redgate'
 } catch { Add-Outcome $id 'Azure alerts' 'NOT CHECKED' $_.Exception.Message 'Alerts Management REST API' }
 try {
  $activity=@(Get-AzActivityLog -ResourceId $id -StartTime $startUtc -EndTime $endUtc -MaxRecord 1000)
  $details.Add([pscustomobject]@{Resource=$id;Check='ActivityLog';Data=$activity})
  $status=if($activity.Count -gt 0){'REVIEW'}else{'INFO'}
  Add-Outcome $id 'Resource activity' $status "Events returned=$($activity.Count) during requested UTC window" 'Review operations/status in JSON. Limit 1000; reaching limit requires a narrower query. Does not cover all subscription Service Health events'
 } catch { Add-Outcome $id 'Resource activity' 'NOT CHECKED' $_.Exception.Message 'Azure Activity Log' }
 if($id -match '/providers/Microsoft.Sql/servers/[^/]+/databases/[^/]+$'){
  try {
   $policyResponse=Invoke-AzRestMethod -Method GET -Path ($id+'/backupShortTermRetentionPolicies/default?api-version=2023-08-01')
   if([int]$policyResponse.StatusCode -ne 200){throw "Backup policy HTTP status $($policyResponse.StatusCode)"}
   $backupPolicy=$policyResponse.Content | ConvertFrom-Json
   $database=Get-AzResource -ResourceId $id -ExpandProperties
   $earliest=$database.Properties.earliestRestoreDate
   $status=if($earliest){'REVIEW'}else{'NOT CHECKED'}
   Add-Outcome $id 'SQL Database restore policy' $status "Retention days=$($backupPolicy.properties.retentionDays); earliest restore date=$earliest" 'Earliest restore date/policy only; confirm latest recoverable point and business recovery requirement separately'
   $details.Add([pscustomobject]@{Resource=$id;Check='ShortTermBackupPolicy';Data=$backupPolicy;EarliestRestoreDate=$earliest})
  }catch{Add-Outcome $id 'SQL Database restore policy' 'NOT CHECKED' $_.Exception.Message 'Short-term retention policy API'}
 }
 if (-not $item.Metrics -or @($item.Metrics).Count -eq 0) {
  Add-Outcome $id 'Azure metrics' 'NOT CHECKED' 'No metric policies configured.' 'Use Get-AzMetricDefinition to select supported metrics'
 }
 foreach ($policy in @($item.Metrics)) {
  if ($null -eq $policy) { continue }
  try {
   $definition=@(Get-AzMetricDefinition -ResourceId $id | Where-Object {$_.Name.Value -eq $policy.Name})
   if($definition.Count -eq 0){throw "Metric $($policy.Name) is not exposed on this resource."}
   $metrics=@(Get-AzMetric -ResourceId $id -MetricName $policy.Name -StartTime $startUtc -EndTime $endUtc -TimeGrain ([TimeSpan]::FromMinutes(5)) -AggregationType Average -DetailedOutput)
   $details.Add([pscustomobject]@{Resource=$id;Check="Metric $($policy.Name)";Data=$metrics})
   $series=@($metrics | ForEach-Object {$_.Timeseries})
   if($series.Count -eq 0){throw 'No metric time series returned.'}
   $seriesNumber=0
   foreach($s in $series) {
    $seriesNumber++
    $all=@($s.Data | Sort-Object TimeStamp)
    $samples=@($all | Where-Object {$null -ne $_.Average})
    if($samples.Count -eq 0){throw 'No non-null Average samples returned.'}
    $longest=0; $streak=0; $previous=$null
    foreach($point in $all){
     $time=([DateTime]$point.TimeStamp).ToUniversalTime()
     if($null -ne $point.Average -and [double]$point.Average -ge [double]$policy.WarningValue){
      if($null -ne $previous -and ($time-$previous).TotalMinutes -le 5.1){$streak++}else{$streak=1}
      if($streak -gt $longest){$longest=$streak}
      $previous=$time
     }else{$streak=0;$previous=$null}
    }
    $peak=($samples | Measure-Object -Property Average -Maximum).Maximum
    $mean=($samples | Measure-Object -Property Average -Average).Average
    $expected=[Math]::Ceiling($Hours*60/5)
    $coverage=[Math]::Min(100,[Math]::Round(100*$samples.Count/$expected,1))
    $latest=([DateTime]$samples[-1].TimeStamp).ToUniversalTime()
    $status=if($longest -ge 3){'ATTENTION'}elseif($peak -ge [double]$policy.WarningValue -or $coverage -lt 90 -or ($endUtc-$latest).TotalMinutes -gt 15){'REVIEW'}else{'INFO'}
    Add-Outcome $id "Metric $($policy.Name) series $seriesNumber" $status "Mean=$([Math]::Round($mean,2)); peak 5-min average=$peak; threshold=$($policy.WarningValue); longest high run=$longest bins; coverage approx=$coverage%; latest UTC=$($latest.ToString('o'))" "Unit=$($definition[0].Unit); 3 consecutive high bins prompts attention; gaps/peaks prompt review; not a completeness guarantee"
   }
  }catch{Add-Outcome $id "Metric $($policy.Name)" 'NOT CHECKED' $_.Exception.Message 'Azure Monitor metric collection'}
 }
 Add-Outcome $id 'Recovery and remaining controls' 'NOT CHECKED' 'Confirm restore coverage, retention, backup failures, DR topology, security alerts, automation and subscription Service Health separately.' 'Not collected by this generic resource script; see README'
}
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null
$stamp=$endUtc.ToString('yyyyMMddTHHmmssfffZ')
$csv=Join-Path $OutputDirectory "AzureDaily-$stamp.csv"
$json=Join-Path $OutputDirectory "AzureDailyEvidence-$stamp.json"
$rows | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
@{StartUtc=$startUtc.ToString('o');EndUtc=$endUtc.ToString('o');Subscription=$context.Subscription.Id;Details=$details.ToArray()} |
 ConvertTo-Json -Depth 30 | Set-Content -LiteralPath $json -Encoding UTF8
$rows | Select-Object Resource,CheckName,Status,Finding | Format-Table -Wrap
Write-Host "Results: $csv"
Write-Host "Evidence: $json"
