# DBA daily checks scripts

Prepared for William Ampiah. Version 1.4, 13 October 2026. Corrected lock timeout syntax, metadata conversions and mixed collations. The AG section now explicitly handles servers with AG disabled or enabled without a visible AG.

These scripts collect evidence for your daily checks report. They do not send email, run maintenance, change Azure resources, clear caches, reset statistics, kill sessions or grant permissions. SQL writes are limited to session-scoped temp tables in tempdb. PowerShell writes evidence files locally.

## Start here

1. Run `01_SQL_Server_and_MI.sql` in SSMS against one SQL Server or Managed Instance first. Use an account whose authorised permissions cover the required resources. Review its output before using Registered Servers for a wider group.
2. Populate `#BackupPolicy` and `#JobPolicy` in that script using your actual schedules. The commented inserts are examples only. Without policies the script deliberately reports REVIEW or NOT CHECKED.
3. Change `@MaintenanceDatabase` to the database containing Ola Hallengren's `dbo.CommandLog`, if used. If you use another maintenance solution, retain NOT CHECKED and review its own logs.
4. Run `02_Azure_SQL_Database.sql` separately in each Azure SQL user database. It is not the Managed Instance script and should not be run in logical master.
5. Copy `azure-resources.example.json` to `azure-resources.json`, replace the resource ID and choose supported metrics/approved thresholds. Run the PowerShell script from a machine with Azure access.
6. Resolve or ticket exceptions. Copy the results into your tracker and email only the overall status, exceptions, actions, owners and next update times.

Do not report a server as checked if the connection itself fails. A SQL script cannot return a row from a connection it never established; record that failure in the tracker.

## Files and coverage

| File | Purpose |
|---|---|
| 01_SQL_Server_and_MI.sql | Database state, latest instance start, local backup history, Agent failures and expected runs, running jobs, database/volume space, AG states, current blocking and memory flags, optional deadlock/error-log history, Ola maintenance outcomes |
| 02_Azure_SQL_Database.sql | Database connection, service objective, recent resource utilisation, data/log file usage, current blocking and geo-replication state |
| 03_Azure_Platform.ps1 | Explicit resource inventory, current Resource Health, visible alert history, resource activity, SQL Database short-term retention and earliest restore date, configured Azure Monitor metrics; exports CSV and JSON |
| azure-resources.example.json | Editable SQL Database resource and metric configuration example |

## Configuration in the SQL Server script

Default reporting window is 24 hours. Use 72 hours for a Monday review if you need to cover the weekend. The accepted range is 1–168 hours.

Illustrative thresholds: disk warning below 15% free, critical below 10%; data/log file occupancy review at 90%; current blocked-request wait review at 60 seconds; AG send/redo queue review above 1024 MB. They are starting values, not validated business policy. Queue size alone does not measure your RPO or RTO. Data-file occupancy alone does not mean the disk is full.

Backup policy example, only after replacing the name and confirming the schedule:

```sql
-- Weekly full; daily differential; log backup every 15 minutes with 30-minute tolerance
INSERT #BackupPolicy VALUES (N'YourDatabase',192,30,30);
-- Daily job expected to succeed within 30 hours and run no longer than 180 minutes
INSERT #JobPolicy VALUES (N'Your daily job',30,180);
```

The script excludes copy-only full backups from the scheduled full check. Differential checks are optional. FULL/BULK_LOGGED databases without an explicit log-backup policy are REVIEW, never PASS. Backups on another AG replica, a renamed/dropped/recreated database, purged history or externally managed backups need separate reconciliation. For Managed Instance use its automated backup policy rather than assuming an on-premises schedule. Successful backup history is not a restore test.

For missed jobs, explicitly list the jobs expected on the current instance/replica. Account for weekends, holidays, monthly schedules and disabled jobs approved by change. Failed job outcomes remain visible even when a later retry succeeded; review before escalation. Failed individual steps in otherwise successful jobs and external schedulers are outside this collection.

Set `@ReadErrorLogs=1` to inspect the current SQL error log and up to six archives within the server-local reporting window. Increase `@ErrorLogArchives` up to 20 only if needed. This is keyword triage, not complete error classification. Missing archives are recorded. Review surrounding messages for each candidate. Rotated/deleted history and timezone changes can leave gaps.

Set `@ReadDeadlockFiles=1` only after checking retained XE volume. The optional scan reads the retained matching files before applying the UTC time filter. With a large system_health collection, use your Redgate deadlock history or a dedicated capture instead. The script reports retained coverage and does not call a zero count proof of no deadlocks. Provide an authorised explicit `@XePattern` for blob/Managed Instance targets; it does not create credentials. No raw deadlock XML or application SQL text is returned in the daily summary.

Host-volume checks include only volumes holding database files. Other volumes, mount points without database files, guest OS health, VM extensions and Azure disk/VM I/O throttling require infrastructure monitoring. Managed Instance host disks are not checked.

On a standalone SQL Server with `IsHadrEnabled=0`, the AG check reports N/A and the other checks run. With AG enabled but no visible AG, it reports REVIEW until expected topology and permissions are verified. On an AG replica, it reads the visible replica and database states. Backup and job policies must account for each replica's role and backup preference; local `msdb` history alone does not validate backups performed on another replica.

## Azure PowerShell setup and execution

Use PowerShell 7 or Windows PowerShell 5.1 with compatible installed Az modules: Az.Accounts, Az.Resources and Az.Monitor. Installation and authentication are separate actions; the script does neither.

```powershell
# Authenticate separately using your approved method
Connect-AzAccount
Set-AzContext -SubscriptionId 'YOUR-SUBSCRIPTION-ID'

# Discover metric names for your actual resource
Get-AzMetricDefinition -ResourceId 'YOUR-RESOURCE-ID' |
    Select-Object @{Name='Metric';Expression={$_.Name.Value}}, Unit

.\03_Azure_Platform.ps1 -ConfigPath .\azure-resources.json `
    -OutputDirectory .\DailyResults -Hours 24
```

Run once per subscription; all listed resource IDs must match the selected subscription. Resource Health may not be exposed for every resource type. Unsupported metrics and missing permissions produce NOT CHECKED.

The example JSON is for Azure SQL Database. For Managed Instance, VMs or elastic pools, use metric names discovered on those exact resources. Add the VM resource separately from the SQL virtual-machine extension resource; they expose different metrics. Average aggregation is used: choose metrics that support Average, and use thresholds in the metric's published units. Count/total-only metrics need separate queries. For VM disk metrics with dimensions, inspect the saved series metadata; do not assume a series represents every disk.

Metric summaries use 5-minute averages, distinguish peaks from three consecutive high bins, and identify low approximate sample coverage or stale samples. They do not capture sub-minute spikes or guarantee complete telemetry. Raw series are retained in JSON.

The alert query includes 30-day visible history so previously fired alerts can be reviewed. Alerts older than that, rule scope, disabled rules and unsupported alert sources need separate review. Resource activity is capped at 1000 records; reaching the cap requires narrower queries. The resource Activity Log is not a substitute for subscription-level Service Health review.

CSV and JSON filenames include UTC timestamps; repeated runs do not intentionally replace earlier output. Evidence can contain resource IDs and operational details. Store and share according to your team's normal access controls.

## Permissions and coverage

Arrange minimum authorised read permissions with your DBA/security team. No grants are included. SQL Server generally requires appropriate server/database monitoring rights; SQL Server 2022 introduces VIEW SERVER PERFORMANCE STATE for several DMVs. XE, error-log, msdb and maintenance-table access can require additional rights. Metadata visibility and restricted msdb roles can silently hide jobs or databases even when a query succeeds.

Azure SQL Database permissions vary by service objective and DMV. An explicit database monitoring-permission check guards current blocking, but complete visibility still needs verification against your known inventory. Azure control-plane collection requires read access to each configured resource, metrics, alerts, activity logs and Resource Health. Successful Azure resource reads do not prove SQL/application connectivity.

Statuses:

| Status | Meaning |
|---|---|
| CRITICAL | Example critical threshold breached; assess and escalate using your policy |
| ATTENTION | Failure or threshold condition needing investigation |
| NOT CHECKED | Missing permission, missing data, disabled collection or a control outside scope |
| REVIEW | Evidence collected but policy, expected topology, retention or interpretation is unresolved |
| PASS | Only the specific stated check passed within its stated visibility/time scope |
| INFO | Measurement or history collected without a complete health judgement |
| N/A | Control does not apply to that platform |

All summary result sets include blank Ticket, Owner and NextUpdate fields for your operational record. A 3-second lock timeout reduces waiting; it does not guarantee queries cannot block or consume resources. The scripts do not change the transaction isolation level. Run outside an existing explicit transaction. Do not run all servers simultaneously before measuring the first run.

SQL backup/job/maintenance/error-log timestamps are server-local and are labelled accordingly. XE, Azure metrics and CheckTimeUtc use UTC. Convert UTC to Europe/London in your reporting tool; do not use a permanent +1-hour offset because BST changes seasonally.

## Checks still needing another source or scheduled process

- Confirm recovery point coverage in Azure SQL restore/backup views or portal; review backup failures and the latest restore-test evidence. The PowerShell script records SQL Database short-term retention and earliest restore date, but does not validate the latest recoverable point or full coverage. MI/VM backup policy, long-term retention and restore testing remain separate checks.
- Review Redgate/Azure Monitor historical blocking, timeouts and incident trends. Current DMV snapshots cannot prove overnight health.
- Review Query Store regressions against your chosen baseline, rather than treating raw wait/CPU counters as a pass/fail check.
- Confirm every expected database completed scheduled integrity checks. CommandLog entries do not by themselves prove coverage.
- Review Azure failover-group roles/policies, MI geo-replication, security alerts, subscription Service Health and external scheduler failures.
- Retain your scheduled access reviews, restore tests, DR exercises, capacity forecasts and change validation.

## Validation and limitations

The package was checked locally for SQL string/comment and delimiter balance, including embedded dynamic-SQL text, JSON validity, packaging and read-only command intent. These are static checks, not engine compilation. No SQL Server, Managed Instance, Azure subscription or PowerShell/Az runtime was available for live execution. This is an initial implementation for your controlled first run; successful production execution and estate-wide visibility have not been demonstrated. Share any errors with the script name, section and server version, and remove sensitive values before sharing.

## Microsoft references

- SQL monitoring permissions and host volumes: https://learn.microsoft.com/en-us/sql/relational-databases/system-dynamic-management-objects/sys-dm-os-volume-stats-transact-sql
- AG database states: https://learn.microsoft.com/en-us/sql/relational-databases/system-dynamic-management-objects/sys-dm-hadr-database-replica-states-transact-sql
- XE retained-file reading: https://learn.microsoft.com/en-us/sql/relational-databases/system-functions/sys-fn-xe-file-target-read-file-transact-sql
- Azure SQL recent resource stats: https://learn.microsoft.com/en-us/sql/relational-databases/system-dynamic-management-objects/sys-dm-db-resource-stats-azure-sql-database
- MI backup history: https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/backup-activity-monitor
- Azure SQL geo-replication status: https://learn.microsoft.com/en-us/sql/relational-databases/system-dynamic-management-objects/sys-dm-geo-replication-link-status-azure-sql-database
- Azure metrics cmdlet: https://learn.microsoft.com/en-us/powershell/module/az.monitor/get-azmetric
- Azure alerts API: https://learn.microsoft.com/en-us/rest/api/alerts-management/alerts/alerts/get-all
- Resource Health API: https://learn.microsoft.com/en-us/rest/api/resourcehealth/availability-statuses/get-by-resource
